create definer = swcamp@`%` trigger trg_reaction_after_delete
    after delete
    on comment_reaction
    for each row
BEGIN
    DECLARE comment_author_num INT;

    -- 1. 댓글 자체의 카운트 업데이트
    UPDATE comment
    SET good = good - CASE WHEN OLD.reaction_type = 'GOOD' THEN 1 ELSE 0 END,
        cheer = cheer - CASE WHEN OLD.reaction_type = 'CHEER' THEN 1 ELSE 0 END
    WHERE num = OLD.comment_num;

    -- 2. 댓글 작성자 검색
    SELECT member_num
    INTO comment_author_num
    FROM comment
    WHERE num = OLD.comment_num;

    -- 3. 댓글 작성자의 누적 카운트 업데이트
    UPDATE member
    SET good_count = good_count - CASE WHEN OLD.reaction_type = 'GOOD' THEN 1 ELSE 0 END,
        cheer_count = cheer_count - CASE WHEN OLD.reaction_type = 'CHEER' THEN 1 ELSE 0 END,
        monthly_good_count = monthly_good_count - CASE WHEN OLD.reaction_type = 'GOOD' THEN 1 ELSE 0 END
    WHERE num = comment_author_num;
END;

