create definer = swcamp@`%` trigger trg_review_post_after_update
    after update
    on review_post
    for each row
BEGIN
    IF OLD.good <> NEW.good OR OLD.cheer <> NEW.cheer THEN
        UPDATE Member
        SET
            good_count = good_count + (NEW.good - OLD.good),
            cheer_count = cheer_count + (NEW.cheer - OLD.cheer),
            monthly_good_count = monthly_good_count + (NEW.good - OLD.good) -- monthly는 good만 반영
        WHERE num = NEW.member_num;
    END IF;
END;

